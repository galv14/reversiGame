/*
Name:Yair Shlomo
ID: 308536150
Name:Gal Eini
ID: 305216962
*/
#ifndef CLIENT_H
#define CLIENT_H
#include "Player.h"
#include<stdio.h>
#include<string>
#include <stdlib.h>
#define MAX_COMMAND_LEN 50
class Client :public Player {
public:
    /**
     * Constructor.
    */
    Client(char sign ,const char *serverIP, int serverPort);
    /**
    * moveTurn function-move the turn to the second player if there are no moves for him.
    */
    void moveTurn();
    /**
    * sendMessage function-send a message to the other player.
    * @param message - a message.
   */
    void sendMessage(char* message);
    /**
   * connectToServer function-connect the client to the server
   */
    void connectToServer();
    /**
* yourPlay is a abstract. returns a point play fom user.
*/
    Point* yourPlay(vector<Point> vec);
    /**
* * checkNextTurn is a abstract. checks if there is any option of play to Player.
*/
    bool checkNextTurn(GameLogic* logic);
    /**
   * getMessage function-get a message from the server
   */
    char* getMessage();
    /**
   * endGame function- end the game
   */
    void endGame();
    /**
   * closeMe function-close the game from the client
   */
    void closeMe();

private:
    // server IP
    const char *serverIP;
    // server port
    int serverPort;
    // client socket
    int clientSocket;
    // a buffer for messaging
    char buffer[MAX_COMMAND_LEN];
};
#endif /*CLIENT_H*/
